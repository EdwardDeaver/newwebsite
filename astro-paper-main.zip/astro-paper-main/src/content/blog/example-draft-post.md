---
title: Example Draft Post
author: Sat Naing
pubDatetime: 2022-06-06T04:06:31Z
slug: example-draft-post
featured: false
draft: true
tags:
  - TypeScript
  - Astro
description:
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
  incididunt ut labore et dolore magna aliqua. Praesent elementum facilisis leo vel
  fringilla est
---

Users cannot see this post because it is in draft.

## Motivation

rec 1
